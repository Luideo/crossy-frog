<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>Bash</name>
    <message>
        <location filename="bash.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChooseFrog</name>
    <message>
        <location filename="choosefrog.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GameMode00</name>
    <message>
        <location filename="gameMode00.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Menu</name>
    <message>
        <location filename="menu.ui" line="32"/>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <location filename="menu.cpp" line="99"/>
        <source>CROSSY FROG</source>
        <translation>CROSSY FROG</translation>
    </message>
    <message>
        <location filename="menu.cpp" line="106"/>
        <location filename="menu.cpp" line="109"/>
        <location filename="menu.cpp" line="125"/>
        <location filename="menu.cpp" line="139"/>
        <location filename="menu.cpp" line="153"/>
        <location filename="menu.cpp" line="162"/>
        <location filename="menu.cpp" line="165"/>
        <source>Play</source>
        <translation>Jouer</translation>
    </message>
    <message>
        <location filename="menu.cpp" line="111"/>
        <location filename="menu.cpp" line="120"/>
        <location filename="menu.cpp" line="123"/>
        <location filename="menu.cpp" line="140"/>
        <location filename="menu.cpp" line="154"/>
        <location filename="menu.cpp" line="167"/>
        <source>Hall Of Fame</source>
        <translation>Classement</translation>
    </message>
    <message>
        <location filename="menu.cpp" line="112"/>
        <location filename="menu.cpp" line="126"/>
        <location filename="menu.cpp" line="134"/>
        <location filename="menu.cpp" line="137"/>
        <location filename="menu.cpp" line="155"/>
        <location filename="menu.cpp" line="168"/>
        <source>Settings</source>
        <translation>Parametres</translation>
    </message>
    <message>
        <location filename="menu.cpp" line="113"/>
        <location filename="menu.cpp" line="127"/>
        <location filename="menu.cpp" line="141"/>
        <location filename="menu.cpp" line="148"/>
        <location filename="menu.cpp" line="151"/>
        <location filename="menu.cpp" line="169"/>
        <source>Exit</source>
        <translation>Quitter</translation>
    </message>
</context>
<context>
    <name>Splash</name>
    <message>
        <location filename="splash.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
